# piscine-go

I save my exercises here